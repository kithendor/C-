#pragma once
#include "Animali.h"
class Dolphin: public Animali
{
public:
	void print() const;
};

