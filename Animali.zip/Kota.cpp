#include "stdafx.h"
#include "Kota.h"
#include "Animali.h"
#include <iostream>
#include <string>

using namespace std;

void Kota::print() const
{
	cout << "Tin kota tin lene: " << name << endl;
	cout << "Zei sto kotetsi gia " << age << "xronia" << endl;
}


