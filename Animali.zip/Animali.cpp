#include "stdafx.h"
#include "Animali.h"

#include <iostream>
#include <string>

using namespace std;


void Animali::setter(string n, int a)
{
	age = a;
	name = n;
}