#include "stdafx.h"
#include "Dolphin.h"
#include "Animali.h"
#include <iostream>
#include <string>

using namespace std;

void Dolphin::print() const
{
	cout << "To delfini to lene: " << name << endl;
	cout << "Zei sto nero gia " << age << "xronia" << endl;
}
