#include "stdafx.h"
#include "Animali.h"
#include "Dolphin.h"
#include "Kota.h"
#include <iostream>
#include <string>

using namespace std;



int main()
{
	Kota k;
	k.setter("tsiou", 45);
	k.print();


	int x;
	cin >> x;
    return 0;
}

