#pragma once
#include "Animali.h"
class Kota :public Animali
{
public:
	void print() const;
};

