#pragma once
#include <iostream>
#include <string>

using namespace std;
class Animali
{
public:
	void setter(string, int);
protected:
	string name;
	int age;

};

